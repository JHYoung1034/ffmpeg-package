#define PACKAGE_STRING "yasm 1.3.0"
#define PACKAGE_VERSION "1.3.0"
