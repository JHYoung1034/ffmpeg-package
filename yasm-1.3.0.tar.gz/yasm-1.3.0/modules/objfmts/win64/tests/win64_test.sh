#! /bin/sh
${srcdir}/out_test.sh win64_test modules/objfmts/win64/tests "win64 objfmt" "-f win64" ".obj"
exit $?
