#include "libavformat/avformat.h"
#include "libavutil/log.h"



int main(int argc, char *argv[])
{
	int ret;
	AVFormatContext *fmtctx = NULL;

	if (argc != 2) {
		av_log(NULL, AV_LOG_ERROR, "input paramer invalid!\n");
		return -1;
	}

	fmtctx = avformat_alloc_context();
	ret = avformat_open_input(&fmtctx, argv[1], NULL, NULL);
	if (ret != 0) {
		av_log(NULL, AV_LOG_ERROR, "open intput:%s failed, ret:%s\n", argv[1], av_err2str(ret));
		return ret;
	}

	if ((ret = avformat_find_stream_info(fmtctx, NULL))) {
		av_log(NULL, AV_LOG_ERROR, "open intput:%s failed, ret:%s\n", argv[1], av_err2str(ret));
		return ret;
	}

	av_dump_format(fmtctx, 0, NULL, 0);


	avformat_close_input(fmtctx);
	avformat_free_context(fmtctx);

	return 0;
}